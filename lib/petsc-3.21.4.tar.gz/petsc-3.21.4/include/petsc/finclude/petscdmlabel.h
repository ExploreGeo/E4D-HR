!
!
!  Include file for Fortran use of the DMLabel package in PETSc
!
#if !defined (PETSCDMLABELDEF_H)
#define PETSCDMLABELDEF_H

#include "petsc/finclude/petscdm.h"

#define DMLabel          type(tDMLabel)

#endif
